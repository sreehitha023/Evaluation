package com.marketsimplified;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class TradingService extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Connection connection = Database.connect();
    static Logger log = LogManager.getLogger();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        try {
        	JSONArray jsonArray = new JSONArray();
        	StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) 
			{
				jb.append(line);
			}
			JSONObject jsonobj = new JSONObject(jb.toString());
			String symbol = jsonobj.getString("symbol");
			int price = jsonobj.getInt("price");
			int quantity = jsonobj.getInt("quantity");

            // Retrieve stop_limit data for the symbol from the database
            StopLimitData stopLimitData = Service.getStopLimitData(connection,symbol);

            if (stopLimitData != null) {
                int stopPrice = stopLimitData.getStopPrice();
                int limitPrice = stopLimitData.getLimitPrice();
                int tradedQty = stopLimitData.getTradedQty();

                // Check if the price matches the stop price
                if (price == stopPrice) {
                	
                    // Check if the price is within the desired range
                    if (price >= 200 && price <= 215) {
                    	
                        // Calculate the remaining quantity to be bought
                        int remainingQty = 50 - tradedQty;
                        if (remainingQty > 0) {
                        	
                            // Check if the price exceeds the limit price
                            if (price <= limitPrice) {
                            	
                                // Perform the purchase
                                int purchaseQty = Math.min(quantity, remainingQty);
                                Service.updateTradedQty(connection,symbol, tradedQty + purchaseQty);
                                Service.insertPurchaseHistory(connection, symbol, price, quantity);

                                // Check if all orders are filled
                                if (tradedQty + purchaseQty == 50) {
                                    jsonobj.put("error","All orders filled");
                                    jsonArray.put(jsonobj);
                                    return;
                                } else {
                                	jsonobj.put("Success","Purchase successful");
                                	jsonArray.put(jsonobj);
                                    return;
                                }
                            } else {
                            	jsonobj.put("error","Price exceeds the limit. Purchase not allowed.");
                            	jsonArray.put(jsonobj);
                                return;
                            }
                        } else {
                            response.getWriter().println("All orders filled");
                        }
                    } else {
                    	jsonobj.put("error","Price is not within the desired range. Trading not triggered.");
                    	jsonArray.put(jsonobj);
                        return;
                        }
                } else {
                	jsonobj.put("error","Price does not match the stop price. Trading not triggered.");
                	jsonArray.put(jsonobj);
                    return;
                    }
            } else {
                response.getWriter().println("Symbol not found in the stop_limit table.");
            }
        } 
        catch (Exception e) {
        	 response.getWriter().println("Invalid JSON format");
        
        }
        
            
        finally {
        	Database.close(connection);
        }
    }
}