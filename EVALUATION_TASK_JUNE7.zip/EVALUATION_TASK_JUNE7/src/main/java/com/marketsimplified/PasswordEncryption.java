package com.marketsimplified;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * Utility class for password encryption and decryption using AES algorithm.
 */
public class PasswordEncryption {
	private static final String ALGORITHM = "AES";
	private static final String SECRET_KEY = "ThisIsASecretKey";

	/**
	 * Encrypts the given password using AES encryption algorithm.
	 *
	 * @param password the password to be encrypted
	 * @return the encrypted password as a Base64-encoded string, or null if
	 *         encryption fails
	 */
	public static String encrypt(String password) {
		try {
			Key key = generateKey();
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encryptedValue = cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));
			return Base64.getEncoder().encodeToString(encryptedValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Decrypts the given encrypted password using AES decryption algorithm.
	 *
	 * @param encryptedPassword the encrypted password as a Base64-encoded string
	 * @return the decrypted password, or null if decryption fails
	 */
	public static String decrypt(String encryptedPassword) {
		try {
			Key key = generateKey();
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, key);
			byte[] decryptedValue = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
			return new String(decryptedValue, StandardCharsets.UTF_8);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Key generateKey() {
		return new SecretKeySpec(SECRET_KEY.getBytes(StandardCharsets.UTF_8), ALGORITHM);
	}
//	public static void main(String [] args) {
//		System.out.println(encrypt("Sree@1234567"));
//	}
	}
