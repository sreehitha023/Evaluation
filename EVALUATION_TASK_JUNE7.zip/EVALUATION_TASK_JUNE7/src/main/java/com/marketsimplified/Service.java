package com.marketsimplified;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;

public class Service {

	public static StopLimitData getStopLimitData(Connection connection,String symbol) throws ServletException {
        String query = "SELECT * FROM stop_limit WHERE symbol = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, symbol);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int quantity = resultSet.getInt("quantity");
                int stopPrice = resultSet.getInt("stopPrice");
                int limitPrice = resultSet.getInt("limitPrice");
                String action = resultSet.getString("action");
                int tradedQty = resultSet.getInt("tradedQty");

                return new StopLimitData(symbol, quantity, stopPrice, limitPrice, action, tradedQty);
            }
        } catch (SQLException e) {
            throw new ServletException("Error retrieving stop_limit data.", e);
        }
        return null;
    }

    public static void updateTradedQty(Connection connection,String symbol, int tradedQty) throws ServletException {
        String query = "UPDATE stop_limit SET tradedQty = ? WHERE symbol = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, tradedQty);
            statement.setString(2, symbol);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new ServletException("Error updating tradedQty in stop_limit table.", e);
        }
    }

    public static void insertPurchaseHistory(Connection connection,String symbol, int price, int quantity) throws ServletException {
        String query = "INSERT INTO purchase_history (Symbol, Price, Quantity) VALUES (?, ?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, symbol);
            statement.setInt(2, price);
            statement.setInt(3, quantity);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new ServletException("Error inserting purchase history data.", e);
        }
    }
}



